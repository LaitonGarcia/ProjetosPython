from django.conf.urls import include, url
from . import views

urlpatterns = [
    url(r'^$', views.inicio),
    url(r'^inicio/$', views.inicio),
    url(r'^mapa/$',views.mapa),
    url(r'^mapa/infoMapa.html/$',views.infoMapa)
]
