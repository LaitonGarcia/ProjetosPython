from django.db import models
from django.utils import timezone

class Postagem(models.Model):
    autor = models.ForeignKey('auth.User')
    titulo = models.CharField(max_length=200)
    texto = models.TextField()
    imagem1 = models.FileField(upload_to = "blog/static/imagens",blank=True)
    imagem2 = models.FileField(upload_to = "blog/static/imagens",blank=True)
    imagem3 = models.FileField(upload_to = "blog/static/imagens",blank=True)
    descricao_imagem1 = models.TextField(blank=True)
    descricao_imagem2 = models.TextField(blank=True)
    descricao_imagem3 = models.TextField(blank=True)
    created_date = models.DateTimeField(
            default=timezone.now)
    published_date = models.DateTimeField(
            blank=True, null=True)

    def publish(self):
        self.published_date = timezone.now()
        self.save()

    def __str__(self):
        return self.titulo
