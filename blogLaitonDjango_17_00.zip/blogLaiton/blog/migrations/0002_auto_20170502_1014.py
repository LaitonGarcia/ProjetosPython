# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('blog', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='postagem',
            name='imagem1',
            field=models.FileField(upload_to=b'apptcc/static/imagens', blank=True),
        ),
        migrations.AddField(
            model_name='postagem',
            name='imagem2',
            field=models.FileField(upload_to=b'apptcc/static/imagens', blank=True),
        ),
        migrations.AddField(
            model_name='postagem',
            name='imagem3',
            field=models.FileField(upload_to=b'apptcc/static/imagens', blank=True),
        ),
    ]
