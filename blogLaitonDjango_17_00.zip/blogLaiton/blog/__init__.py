# -*- coding: utf 8 -*-

import sys
reload(sys)
sys.setdefaultencoding("utf-8")
