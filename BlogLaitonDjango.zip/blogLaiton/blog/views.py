# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from .models import *

# Create your views here.

def inicio(request):
    postagens = Postagem.objects.all()
    return render(request,'blog/minha_floriano_blog.html',{'postagens':postagens})
